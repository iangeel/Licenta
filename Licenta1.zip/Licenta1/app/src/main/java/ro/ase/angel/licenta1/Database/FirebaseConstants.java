package ro.ase.angel.licenta1.Database;

/**
 * Created by angel on 20.03.2018.
 */

public interface FirebaseConstants {
    String TABLE_NAME_USERS = "Users";
    String TABLE_NAME_RECORDS = "Records";
    String RECORDS_NODE_REFFERENCE = "records";
}
