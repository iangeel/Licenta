package ro.ase.angel.licenta1.Utils;

/**
 * Created by angel on 08.03.2018.
 */

public interface Constants {
    int SPLASH_DISPLAY_LENGTH = 2000;
}
