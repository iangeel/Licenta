#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include "TinyGPS++.h"
#include "SoftwareSerial.h"




#define SERIAL_BUFFER_SIZE 256
#define PROCESSING_VISUALIZER 1
#define SERIAL_PLOTTER  2
#define FIREBASE_HOST "https://iot-android-ivana-angel.firebaseio.com/"
#define FIREBASE_AUTH "wVPUSuNbPzNiq7wdOXO99covLuOavbYLHAYqxs15"
#define clientID "iangeell"


const char* ssid = "ANGELiph";
const char* password = "i123angeell5";
const char* mqtt_server = "m23.cloudmqtt.com";
const char* mqtt_username = "ycstaqvf";
const char* mqtt_password = "mcv2ILaYwu0f";
const char* pulseTestTopic = "/tests/pulse";

WiFiClient espClient;
PubSubClient client(espClient);

//GPS
TinyGPSPlus gps;//This is the GPS object that will pretty much do all the grunt work with the NMEA data
bool waitingData = true;
double latitude;
double longitude;
double speedKm;
static const int RXPin = 4, TXPin = 5;
static const uint32_t GPSBaud = 9600;
SoftwareSerial ss(RXPin, TXPin, false, 256);



//  Variables
int pulsePin = 0;                 // Pulse Sensor purple wire connected to analog pin 0
int blinkPin = D4;                // pin to blink led at each beat
int fadePin = 14;                  // pin to do fancy classy fading blink at each beat
int fadeRate = 0;                 // used to fade LED on with PWM on fadePin

bool stop = false;

// Volatile Variables, used in the interrupt service routine!
volatile int BPM;                   // int that holds raw Analog in 0. updated every 2mS
volatile int Signal;                // holds the incoming raw data
volatile int IBI = 600;             // int that holds the time interval between beats! Must be seeded!
volatile boolean Pulse = false;     // "True" when User's live heartbeat is detected. "False" when not a "live beat".
volatile boolean QS = false;        // becomes true when Arduoino finds a beat.

volatile int rate[10];                    // array to hold last ten IBI values
volatile unsigned long sampleCounter = 0;          // used to determine pulse timing
volatile unsigned long lastBeatTime = 0;           // used to find IBI
volatile int P =512;                      // used to find peak in pulse wave, seeded
volatile int T = 512;                     // used to find trough in pulse wave, seeded
volatile int thresh = 530;                // used to find instant moment of heart beat, seeded
volatile int amp = 0;                   // used to hold amplitude of pulse waveform, seeded
volatile boolean firstBeat = true;        // used to seed rate array so we startup with reasonable BPM
volatile boolean secondBeat = false;      // used to seed rate array so we startup with reasonable BPM

static boolean serialVisual = true;


// FIRST, CREATE VARIABLES TO PERFORM THE SAMPLE TIMING AND LED FADE FUNCTIONS
unsigned long lastTime; // used to time the Pulse Sensor samples
unsigned long thisTime; // used to time the Pulse Sensor samples
unsigned long fadeTime; // used to time the LED fade


///////////////METODE DE CALCUL PENTRU PULS/////////////////////

void ledFadeToBeat(){
    fadeRate -= 15;                         //  set LED fade value
    fadeRate = constrain(fadeRate,0,255);   //  keep LED fade value from going into negative numbers!
    analogWrite(fadePin,fadeRate);          //  fade LED
  }

void getPulse(){                         // triggered when Timer2 counts to 124
//  cli();                                      // disable interrupts while we do this
  Signal = analogRead(pulsePin);              // read the Pulse Sensor
  sampleCounter += 2;                         // keep track of the time in mS with this variable
  int N = sampleCounter - lastBeatTime;       // monitor the time since the last beat to avoid noise

    //  find the peak and trough of the pulse wave
  if(Signal < thresh && N > (IBI/5)*3){       // avoid dichrotic noise by waiting 3/5 of last IBI
    if (Signal < T){                        // T is the trough
      T = Signal;                         // keep track of lowest point in pulse wave
    }
  }

  if(Signal > thresh && Signal > P){          // thresh condition helps avoid noise
    P = Signal;                             // P is the peak
  }                                        // keep track of highest point in pulse wave

  //  NOW IT'S TIME TO LOOK FOR THE HEART BEAT
  // signal surges up in value every time there is a pulse
  if (N > 500){    //era 250                               // avoid high frequency noise
    if ( (Signal > thresh) && (Pulse == false) && (N > (IBI/5)*3) ){
      Pulse = true;                               // set the Pulse flag when we think there is a pulse
    //  digitalWrite(blinkPin,HIGH);                // turn on pin 13 LED
      IBI = sampleCounter - lastBeatTime;         // measure time between beats in mS
      lastBeatTime = sampleCounter;               // keep track of time for next pulse

      if(secondBeat){                        // if this is the second beat, if secondBeat == TRUE
        secondBeat = false;                  // clear secondBeat flag
        for(int i=0; i<=9; i++){             // seed the running total to get a realisitic BPM at startup
          rate[i] = IBI;
        }
      }

      if(firstBeat){                         // if it's the first time we found a beat, if firstBeat == TRUE
        firstBeat = false;                   // clear firstBeat flag
        secondBeat = true;                   // set the second beat flag
//        sei();                               // enable interrupts again
        return;                              // IBI value is unreliable so discard it
      }


      // keep a running total of the last 10 IBI values
      word runningTotal = 0;                  // clear the runningTotal variable

      for(int i=0; i<=8; i++){                // shift data in the rate array
        rate[i] = rate[i+1];                  // and drop the oldest IBI value
        runningTotal += rate[i];              // add up the 9 oldest IBI values
      }

      rate[9] = IBI;                          // add the latest IBI to the rate array
      runningTotal += rate[9];                // add the latest IBI to runningTotal
      runningTotal /= 10;                     // average the last 10 IBI values
      BPM = 60000/runningTotal;               // how many beats can fit into a minute? that's BPM!
      QS = true;                              // set Quantified Self flag
      // QS FLAG IS NOT CLEARED INSIDE THIS ISR
    }
  }

  if (Signal < thresh && Pulse == true){   // when the values are going down, the beat is over
    //digitalWrite(blinkPin,LOW);            // turn off pin 13 LED
    Pulse = false;                         // reset the Pulse flag so we can do it again
    amp = P - T;                           // get amplitude of the pulse wave
    thresh = amp/2 + T;                    // set thresh at 50% of the amplitude
    P = thresh;                            // reset these for next time
    T = thresh;
  }

  if (N > 2500){                           // if 2.5 seconds go by without a beat
    thresh = 530;                          // set thresh default
    P = 512;                               // set P default
    T = 512;                               // set T default
    lastBeatTime = sampleCounter;          // bring the lastBeatTime up to date
    firstBeat = true;                      // set these to avoid noise
    secondBeat = false;                    // when we get the heartbeat back
  }

//  sei();                                   // enable interrupts when youre done!
}// end isr

void arduinoSerialMonitorVisual(char symbol, int data )
{
  const int sensorMin = 0;      // sensor minimum, discovered through experiment
  const int sensorMax = 1024;    // sensor maximum, discovered through experiment
  int sensorReading = data; // map the sensor range to a range of 12 options:
  int range = map(sensorReading, sensorMin, sensorMax, 0, 11);
  // do something different depending on the
  // range value:
  switch (range)
  {
    case 0:
    //  Serial.print("");     /////ASCII Art Madness
      break;
    case 1:
  //    Serial.print("-");
      break;
    case 2:
  //    Serial.print("|");
      break;
    case 3:
  //    Serial.print("-");
      break;
    case 4:
//      Serial.print("|");
      break;
    case 5:
//      Serial.print("-");
      break;
    case 6:
//      Serial.print("|");
      break;
    case 7:
//      Serial.print("-");
      break;
    case 8:
  //    Serial.print("|");
      break;
    case 9:
  //    Serial.print("-");
      break;
    case 10:
  //    Serial.print("|");
      break;
    case 11:
  //    Serial.print("-");
      break;
  }
}

void sendDataToSerial(char symbol, int data ){
    Serial.print(symbol);
    Serial.println(data);
  }

void serialOutput()
{   // Decide How To Output Serial.
 if (serialVisual == true)
  {
     arduinoSerialMonitorVisual('-', Signal);   // goes to function that makes Serial Monitor Visualizer
  }
 else
  {
      sendDataToSerial('S', Signal);     // goes to sendDataToSerial function
   }
}

void serialOutputWhenBeatHappens()
{
 if (serialVisual == true) //  Code to Make the Serial Monitor Visualizer Work
   {
     Serial.print("*** Heart-Beat Happened *** ");  //ASCII Art Madness
     Serial.print("Your BPM is : ");
     Serial.println(BPM);
   }
 else
   {
     sendDataToSerial('B',BPM);   // send heart rate with a 'B' prefix
     sendDataToSerial('Q',IBI);   // send time between beats with a 'Q' prefix
   }
}


/////////////////////////WiFi + MQTT///////////////////////////

void wifi_setup() {
  delay(10);
  // Serial.println();
  // Serial.println();
  // Serial.print("Connecting to ");
  // Serial.println(ssid);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
  //  Serial.print(".");
  }
  // Serial.println("");
  // Serial.println("WiFi connected");
  // Serial.println("IP address: ");
  // Serial.println(WiFi.localIP());
}



void callback(char* topic, byte* payload, unsigned int length) {
  String topicString = topic;

  // Serial.println("Callback update.");
  // Serial.println("Topic: ");
  // Serial.println(SERIAL_BUFFER_SIZE);
  // Serial.print(topicString);

  if(payload[0] == '1') {

    client.publish("/tests/confirm", String(BPM).c_str());
    client.publish("/tests/confirm", String(speedKm).c_str());


  } else if (payload[0] == '0') {
    client.publish("/tests/ceva", "altceva");
  }

}


void reconnect() {
  while (!client.connected()) {
//  Serial.print("Attempting MQTT connection...");
  // Incercam reconectarea
  if (client.connect(clientID, mqtt_username, mqtt_password)) {
//    Serial.println("connected");
    if(client.subscribe(pulseTestTopic)) {
//      Serial.println("Subscribed to ");
//      Serial.print(pulseTestTopic);
    }

  } else {
    // Serial.print("failed, rc=");
    // Serial.print(client.state());
    // Serial.println(" try again in 5 seconds");
    // Asteptam 5 secunde inainte de a reincerca
    delay(5000);
  }
}
}


void retriveDataFromGPS() {
 Serial.print(F("Location & Speed: "));
  if (gps.location.isValid())
  {
    latitude = gps.location.lat();
    longitude = gps.location.lng();
    speedKm = gps.speed.kmph();
    Serial.print(gps.location.lat(), 6);
    Serial.print(F(","));
    Serial.print(gps.location.lng(), 6);
    Serial.println();
    Serial.print(gps.speed.mph());
  }
  else
  {
   Serial.print(F("INVALID"));
  }


 Serial.println();

}

void GPSloop() {
  while (ss.available() > 0) {

    if (gps.encode(ss.read())) {
      //Serial.print("gps.read: OK");
      // Serial.println();
      // Serial.println(ss.read());
      retriveDataFromGPS();
    }
  }
}




void setup() {
  // digitalWrite(LED_BUILTIN, LOW);
  // pinMode(blinkPin,OUTPUT);         // setam pinul principal care sa bipaie cand se inregistreaza o bataie a inimii
  // pinMode(fadePin,OUTPUT);          // pin ul care ar trebui sa aiba un efect de fade la inregistrarea pulsului
  Serial.begin(115200);             // setam rata baud la 115200 pentru a vedea in Serial monitor
  ss.begin(GPSBaud);
//  ss.begin(GPSBaud);
//  Serial.print(SERIAL_BUFFER_SIZE);
  lastTime = micros(); //initializam variabila lastTime cu nr de microsecunde care au trecut de cand placuta a inceput sa ruleze programul

  wifi_setup();
  client.setServer(mqtt_server, 13090);
  client.setCallback(callback);

}

void loop() {

//  serialOutput() ;

  if(!client.connected()) {
    reconnect();
  }
  client.loop();






  thisTime = micros();            // GET THE CURRENT TIME
  if(thisTime - lastTime > 2000){ // CHECK TO SEE IF 2mS HAS PASSED
    lastTime = thisTime;          // KEEP TRACK FOR NEXT TIME
    getPulse();                   //CHANGE 'ISR(TIMER2_COMPA_vect)' TO 'getPulse()' IN THE INTERRUPTS TAB!
    GPSloop();

  }

  if (QS == true){     // A Heartbeat Was Found
                       // BPM and IBI have been Determined
                       // Quantified Self "QS" true when arduino finds a heartbeat
        fadeRate = 255;         // Makes the LED Fade Effect Happen
                                // Set 'fadeRate' Variable to 255 to fade LED with pulse
        fadeTime = millis();    // Set the fade timer to fade the LED
    //    serialOutputWhenBeatHappens();   // A Beat Happened, Output that to serial.
    //    client.publish(pulseTestTopic, String(BPM).c_str(), false);

        QS = false;                      // reset the Quantified Self flag for next time
  }

  // if(millis() - fadeTime > 20){
  //   fadeTime = millis();
  //   ledFadeToBeat();                      // Makes the LED Fade Effect Happen
  //   }

    //delay(10); //pt wifi
}
